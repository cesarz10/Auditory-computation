function [signalp]=dynamic_compressor(signal,fsy,Gtable,gt,freq,W,ta,tr)
% Dynamic Range Compressor implemented from 
% "Implementation and evaluation of an experimental hearing aid dynamic
% range compressor" by Giso Grimm et al.
% 
% Fotis Drakopoulos, University of Ghent
%
% signal, fsy: input signal to be processed and its sampling frequency
% (default = 16 kHz)- the signal will be downsampled to 16 kHz for the
% processing.
% 
% Gtable(k,L) is the gain table fitted for an individual hearing loss 
% profile. Each element of the table corresponds to an insertion gain 
% applied for each respective frequency and for each respective input 
% level. The values can be either positive (amplification) or negative 
% (attenuation). The 1st dimension of the table corresponds to the 
% frequency bins of the STFT of the input (given in the freq(k) array) and 
% the 2nd dimension corresponds to the input levels in dB-SPL (given in the
% gt(L) array). If no argument is given, zero gain is applied.
% The Gtable can also be a row array. In this case, the gain applied is
% only frequency dependent (the same gain is applied for all input levels).
% f: The frequencies of the STFT bins corresponding to the 1st dimension
% of the Gtable. If not defined, the default frequencies for each bin are 
% computed by f=(1:(W))*(16e3/(2*W)), where W = 64 by default.
% gt: The input intensity levels in dB-SPL corresponding to the 2nd
% dimension of the Gtable. The values need to be positive.
% 
% W: frame size (default = 64) - twice the size is used for the FFT (after 
% zero-padding) and 50% overlap is used between the frames
% ta: attack time constant (default = 20ms)
% tr: release time constant (default = 100ms)
%
% spl_norm variable is used to define the scaling of the magnitudes to
% dB-SPL (default is ~94)
%

if nargin<2
    fsy=16e3; % sampling frequency of the signal
end

if nargin<6
    W=64; % frame size
end
if nargin<7
    ta=0.02; % attack time constant (20ms)
end
if nargin<8
    tr=0.1; % release time constant (100ms)
end
if nargin<4 || length(gt) < 2
    gtstep=10; % gain table granulation in dB
    gtmin=10; % minimum is 10 dB-SPL
    gtmax=100; % maximum is 100 dB-SPL
    gt=(gtmin:gtstep:gtmax);
    if nargin < 3
        Gtable=zeros(W,length(gt));
    else
        Gtable = repmat(Gtable,1,length(gt));
    end
end

if isrow(signal)
    signal=signal';
end

spl_norm=20*log10(2e-5); % dB reference of the spectrogram to convert the scale to dB-SPL
db_offset=200; % just an offset to perform logarithmic interpolation over negative values

h=0.5; % overlap percentage 
wnd=hamming(W);
npad=W; % zero-padding size 
fs=16e3; % resample the signal to 16kHz 
xr = resample(signal,fs,fsy);

if nargin<5
    freq=(1:(W+npad)/2)*(fs/(W+npad));  % array of Hz corresponding to bins
    Gtable = repmat(Gtable,length(freq),1);
end

% if the gain table provided is not described for each frequency bin,
% compute the rest of them via logarithmic interpolation
if size(Gtable,1) ~= W
    f=(1:(W+npad)/2)*(fs/(W+npad));
    Gt=Gtable;
    for n=1:length(gt)
        for k=1:(W+npad)/2
            Gtable(k,n) = (interp1(log10(freq),(Gt(:,n)),log10(f(k)),'linear','extrap'));
        end
    end
    freq=f;
    clear Gt f;
end

pads=(1-h)*W;
x=[zeros(pads,1);xr;zeros(pads,1)];

% segment signal for FFT (STFT)
L=length(x);
sp=fix(W.*h);
N=fix((L-W)/sp+1); %number of segments
Index=(repmat(1:W,N,1)+repmat((0:(N-1))'*sp,1,W))';
hw=repmat(wnd,1,N);
xs=x(Index).*hw;

% coli = 1 + ((pads/(h*W)):N-1-(pads/(h*W)))*(h*W);
% t = ((coli-1)+((W+npad)/2)')/fs;

% pad with zeros
pad=zeros((npad/2),size(xs,2));
x_pad=[pad' xs' pad'];
xs=x_pad';
clear x_pad;

% STFT
X=fft(xs); % whole STFT
XPhase=angle(X(1:ceil(end/2),:)); % Phase
X2=abs(X(1:ceil(end/2),:)).^2; % Spectrogram

frames=size(X,2);

aa=exp(-1./(ta*fs)); % attack coefficient
ar=exp(-1./(tr*fs)); % release coefficient

% for computing the input intensity using a max criterion - not used here
% La(:,1)=10.*log10(X2(:,1));
% Lr(:,1)=10.*log10(X2(:,1));

Lin(:,1)=10.*log10(X2(:,1))-spl_norm; % input intensity - first bin
for n=2:frames
    % input intensity for the gain table - positive and negative bins are
    % taken into account
    Xlev(:,n)=10.*log10(2*X2(:,n))-spl_norm;
    for k=1:size(Xlev,1)
        % apply the attack and release filters to the input intensity
        if Xlev(k,n) <= Lin(k,n-1)
            Lin(k,n) = aa*Lin(k,n-1)+(1-aa)*Xlev(k,n);
        else
            Lin(k,n) = ar*Lin(k,n-1)+(1-ar)*Xlev(k,n);
        end
        
% for applying the attack/release filters using a max criterion - not used here
%         La(k,n) = aa*La(k,n-1)+(1-aa)*Xlev(k,n);
%         Lr(k,n) = ar*Lr(k,n-1)+(1-ar)*La(k,n);
%         Lin(k,n) = max(La(k,n),Lr(k,n)))

        if Lin(k,n)<0 % negative values are not needed
            Lin(k,n)=0;
        end
        G(k,n) = (interp1(log10(gt+db_offset),(Gtable(k,:)),log10(Lin(k,n)+db_offset),'linear','extrap'));
        % gain to be applied computed with logarithmic interpolation
        % extrapolation used for values outside the given SPL range.
    end
end

Y2=10*log10(X2)+G; % processed STFT

y=OverlapAdd2(10.^(Y2/20),XPhase,(W+npad),h*W);
y=y(pads+npad/2+1:end-pads-npad/2); % processing signal in time domain

signalp = resample(y,fsy,fs); % upsample the signal to its original sampling rate

end

function ReconstructedSignal=OverlapAdd2(XNEW,yphase,windowLen,ShiftLen,ifftsym)

%Y=OverlapAdd(X,A,W,S);
%Y is the signal reconstructed signal from its spectrogram. X is a matrix
%with each column being the fft of a segment of signal. A is the phase
%angle of the spectrum which should have the same dimension as X. if it is
%not given the phase angle of X is used which in the case of real values is
%zero (assuming that its the magnitude). W is the window length of time
%domain segments if not given the length is assumed to be twice as long as
%fft window length. S is the shift length of the segmentation process ( for
%example in the case of non overlapping signals it is equal to W and in the
%case of %50 overlap is equal to W/2. if not givven W/2 is used. Y is the
%reconstructed time domain signal.
%Sep-04
%Esfandiar Zavarehei

if nargin<2
    yphase=angle(XNEW);
end
if nargin<3
    windowLen=size(XNEW,1)*2;
end
if nargin<4
    ShiftLen=windowLen/2;
end
if fix(ShiftLen)~=ShiftLen
    ShiftLen=fix(ShiftLen);
    disp('The shift length have to be an integer as it is the number of samples.')
    disp(['shift length is fixed to ' num2str(ShiftLen)])
end

if nargin<5
    ifftsym='symmetric';
end

[~, FrameNum]=size(XNEW);

Spec=XNEW.*exp(1i*yphase);

% if mod(windowLen,2) %if FreqResol is odd
%     Spec=[Spec;flipud(conj(Spec(2:end,:)))];
% else
%     Spec=[Spec;flipud(conj(Spec(2:end-1,:)))];
% end
% sig=zeros((FrameNum-1)*ShiftLen+windowLen,1);
sig=zeros((FrameNum)*ShiftLen+windowLen,1);
% weight=sig;
for i=1:FrameNum
    start=(i-1)*ShiftLen+1;
    spec=Spec(:,i);
    ibuffer=real(ifft(spec,windowLen,ifftsym));
    sig(start:start+windowLen-1)=sig(start:start+windowLen-1)+ibuffer;
end
ReconstructedSignal=sig;

% if max(abs(ReconstructedSignal))>1
%     ReconstructedSignal=ReconstructedSignal./max(abs(ReconstructedSignal));
% end

end
