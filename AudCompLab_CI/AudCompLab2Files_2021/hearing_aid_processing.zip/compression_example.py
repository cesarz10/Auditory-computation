# -*- coding: utf-8 -*-
"""
Example script to apply the dynamic compression algorithm

Created on Thu Mar 19 13:11:30 2020

@author: fotisdr
"""

from dynamic_compressor import dynamic_compression, wavfile_read
import scipy.io
import numpy as np

signal, fs_signal = wavfile_read('example.wav') # example wavfile
L = 70 # calibration level of the signal in dB-SPL
f = scipy.io.loadmat('plack2004.mat')

signal = 2e-5*10**(L/20)*signal/(np.sqrt(np.mean(signal**2))) # calibrate

Gtable=f['Gtable']
gt=f['gt'].ravel() # make sure it's one-dimensional
freq=f['freq'].ravel() # make sure it's one-dimensional

signalp=dynamic_compression(signal,fs_signal=fs_signal,Gtable=Gtable,freq=freq,gt=gt)

#scipy.io.wavfile.write('signal.wav',fs_signal,signal)
scipy.io.wavfile.write('signalp.wav',fs_signal,signalp)
