function [subsignalp,subsignal] = CI_processing(signal,fsy,M,Ts,MCL,THL,IDR)
% Paradigm of a simple processing strategy applied in Cochlear Implants. 
% A biphasic pulse is used modulated according to the acoustic amplitude.
% Adapted from the High Resolution Strategy (HiRes).
% 
% Fotis Drakopoulos, Ghent University
%
% signal, fsy: input signal to be processed and its sampling frequency
% (default = 16 kHz)- the signal will be downsampled to 16 kHz for the
% processing.
%
% M: the size of the filterbank - if 1 is given then no fb is used
% Ts: duration of a stimulation cycle in secs - default is 1 ms
% 
% MCL, THL, IDR: If these arguments are provided then a logarithmic 
% compression function is used which ensures that the envelope outputs fit 
% the patient's dynamic range. If no arguments are given then no
% compression is appliedsignal,fsy,M,Ts,MCL,THL,IDR
% MCL, THL: Most Comfortable Level and Threshold in dB-SPL for each 
% frequency band - the arrays must have the same size as the value of M. 
% IDR: The input dynamic range (set by the clinicial) - default is 60 dB.
%

if nargin<3
    M = 16;
end
if nargin<4
    Ts = 0.001;
end
if nargin<5
    compression=0;
end
if nargin<7
    IDR = 60;
end
msat = 20*log10(2^15 - 1); % saturation level - default is 90 dB

fs=16e3; % resample the signal to 16kHz 
xr = resample(signal,fs,fsy)';

% create the biphasic pulse
fc=2/Ts;
ts=0:1/fs:Ts;
p1=0.5.*square(2*pi*fc*ts);
p2=0.5.*square(2*pi*fc/2*ts+pi);
pulse=p1+p2;
% pulse = abs(pulse);

% filterbank
if M>1
    cf = logspace(2.5441,3.7404,M-1);
    Nf = 6;
    
    [b,a]=butter(Nf,cf(1)/(fs/2),'low');
    subsignal(1,:) = filter(b,a,xr);
    [b,a]=butter(Nf,cf(end)/(fs/2),'high');
    subsignal(M,:) = filter(b,a,xr);
    for cbi=2:M-1
        [b,a]=butter(Nf,[cf(cbi-1),cf(cbi)]/(fs/2),'bandpass');
        subsignal(cbi,:) = filter(b,a,xr);
        while max(abs(subsignal(cbi,:))) > max(abs(xr))
            Nf = Nf - 1;
            [b,a]=butter(Nf,[cf(cbi-1),cf(cbi)]/(fs/2),'bandpass');
            subsignal(cbi,:) = filtfilt(b,a,xr);
        end
    end
else
    subsignal=xr;
end

% t=0:1/fs:(size(subsignal,2)-1)/fs;
db_ref = 94; % dB reference for converting to dB
Ns = length(pulse);
subsignalr=zeros(size(subsignal));
for cbi=1:M
    % half wave rectification - the negative parts of the signal are omitted
    subsignalr(cbi,subsignal(cbi,:)>0)=subsignal(cbi,subsignal(cbi,:)>0);
%     subsignalr(cbi,:)=abs(subsignal(cbi,:));
    for i=1:Ns:size(subsignal,2)-Ns
        Xfilt(cbi)=20*log10(mean(subsignalr(cbi,i:i+Ns-1)))+db_ref;
        if ~compression
            % no dynamic compression applied
            Y(cbi)=Xfilt(cbi);
        else
            % apply HiRes compression formula
            Y(cbi)=(MCL(cbi)-THL(cbi)).*(Xfilt(cbi)-msat+12+IDR)./IDR + THL(cbi);
        end
        subsignalp(cbi,i:i+Ns-1) = 10.^((Y(cbi)-db_ref)/20) .*pulse;
    end
end
