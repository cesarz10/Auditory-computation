Dynamic Compressor - Toy Example:
Uses the Plack2004 prescription for a nearly frequency-independent hearing 
loss by applying 30 dB gain for low levels and afterwards reducing the 
gains by 10 dB. This amplification scheme strongly compresses the input 
dynamic, soft sounds are amplified while loud sounds are even attenuated. 
This makes the distinction of soft and loud sounds difficult but prevents 
the amplification of already loud sounds. The 'plack2004.mat' file 
contains the corresponding gain table as well as the respective 
frequencies (1st axis) and signal levels (2nd axis) of the gain table.

The first dimension of the gain table is always the frequency and the
second dimensions is the intensity. The freq and gt variables are used to 
provide the two respective axes. They must always be single-dimensional 
and have the same dimensions as the respective dimensions of the gain 
table.
Gain can be also applied depending only on frequency or only on the input 
level. In this case, Gtable will be an one-dimensional array (column vector 
for frequency - dependent gain / row vector for level-dependent gain). 

--- Python ---

Run the compression_example.py script:
python compression_example.py

# For a level-independent sloping hearing loss, a 10-dB slope gain can be 
# applied after 1 kHz, shaping the gain table as follows:
Gtable=np.array([[0,0,10,20]]).T # example Gtable
freq=np.array([500,1000,2000,4000]) # respective frequencies
gt=np.array([70]) # level-independent - can be omitted

--- MATLAB ---

[signal,fs]=audioread('example.wav'); % any stimulus can be used
L = 70 % calibration level of the signal in dB-SPL
signal=2e-5*10^(L/20)*signal./rms(signal);
load('plack2004.mat');
[signalp]=dynamic_compressor(signal,fs,Gtable,gt,freq);
% plot the Gain Table to get a more clear image of the gain applied
imagesc(gt,freq,Gtable)
title('Gain to be applied')
set(gca,'YDir','normal')
ylabel('Frequency [Hz]')
xlabel('Input Level [dB-SPL]')

% Simple example for a level-independent sloping hearing loss, where a 
10-dB slope gain is applied after 1 kHz:
Gtable=[0;0;10;20];
freq=[500,1000,2000,4000];
gt=70;
[signalp]=dynamic_compressor(signal,fs,Gtable,gt,freq);
% plot the gain rule
semilogx(freq,Gtable)
xlabel('Frequency [Hz]')
ylabel('Gain [dB]')
grid on

---------------------------------------------------------------------------
Cochlear Implant Processing:
Can be called directly from a terminal, giving the necessary arguments:
python CI_processing.py -i name_of_wavfile
(use --help as an argument to print all the possible parameters or consult 
the CI_processing.py script)

Can be also called inside python:
from scipy.io import wavfile
from CI_processing import *
wavfile='example.wav' # example wavfile
subsignalp = ci_processing(wavfile,M,Ts,pulsei,MCL,THL,IDR)
